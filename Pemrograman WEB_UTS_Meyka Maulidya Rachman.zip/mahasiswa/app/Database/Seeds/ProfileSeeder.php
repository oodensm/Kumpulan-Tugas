<?php

namespace App\Database\Seeds;

use CodeIgniter\Database\Seeder;

class ProfileSeeder extends Seeder
{
    public function run()
    {
        $data = [
            [
                'nama' => 'Meyka Maulidya Rachman',
                'alamat' => 'Hulu Sungai Utara, Indonesia',
                'email' => 'meykamaulidyarachman@gmail.com',
                'telp' => '085753305329',
                'gambar' => 'default.jpg'
            ]
        ];

        $this->db->table('profile')->insertBatch($data);
    }
}
