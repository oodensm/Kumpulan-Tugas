<?php
require_once('koneksi.php');

if ((isset($_POST['MM_login'])) && ($_POST['MM_login'] == "meyka")) {
    $loginUsername = $_POST['username'];
    $password = $_POST['password'];

    $LoginRS__query = sprintf(
        "SELECT id, username, password FROM userlogin WHERE username=%s AND password=%s",
        app($koneksi, $loginUsername, "text"),
        app($koneksi, $password, "text")
    );
    $LoginRS = mysqli_query($koneksi, $LoginRS__query) or die(mysqli_error($koneksi));
    $row_rs_LoginRS = mysqli_fetch_assoc($LoginRS);
    $loginFoundUser = mysqli_num_rows($LoginRS);

    //jumlah data lebih dari 0
    if ($loginFoundUser) {
        $response['kode'] = 1;
        $response['pesan'] = "Selamat!! Anda berhasil Login";
        $response['halaman'] = "Screen2";
        
        //tambahan pada video login 2
        $response['data'] = array();
        $no = 1;
        foreach ($LoginRS as $row_rs_LoginRS) {
            $Data['id'] = $row_rs_LoginRS['id'];
            $Data['username'] = $row_rs_LoginRS['username'];
            $Data['password'] = $row_rs_LoginRS['password'];
            array_push($response['data'], $Data);
            $no++;
        }
        //---
    } else {
        $response['kode'] = 0;
        $response['pesan'] = "Gagal";
        $response['halaman'] = "Login";
    }

    echo json_encode($response);
    mysqli_close($koneksi);
}
